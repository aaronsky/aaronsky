
function LoadingAnimation.OnInit()
	
end

function LoadingAnimation.OnEnable()
	this.moveSpeed = 5.0;
end

function LoadingAnimation.Update(dt)

end

function LoadingAnimation.OnDisable()
	
end

function LoadingAnimation.OnDestroy()
	
end
