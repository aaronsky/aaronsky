

function test.OnInit()
	
	local go = SpawnObject("raptor");
	go:
end

