Mineshaft Mayhem
----------------
A wild and crazy minecart adventure! This project was developed from the ground up in 16 weeks using DirectX 11.1. I was responsible for repository and project management, implementing movement and game feel tweaks for the player scripting, and completely reorganizing how scene loading worked.

System Requirements
-------------------
64-bit Windows 7 or higher
1GB of free memory
DirectX 11.1
Shader Model v5.0

Instructions
----------------
1. Extract the zip and run game/MineshaftMayhem.exe
2. AD/LeftRight to switch rails, Space to pause/start game
3. Go as far as possible to get the highest score. Gems are bonus points, arrows are speed boosts, rocks and broken tracks are game over.

Team
----------------
David Erbelding - Lead Gameplay Programmer - http://people.rit.edu/dje3873/Portfolio/index.html
Braxton Frederick - Gameplay Programmer - http://www.braxton.xyz/
Matt Guerrette - Lead Engine Programmer - https://github.com/MattGuerrette
Brian Nunget - Modeler, Texture Artist - http://briannugent.me
Aaron Sky - Project Manager, Gameplay Programmer - http://skyaaron.com